package hello.core.member;

public enum Grade { // 클래스 처럼 보이게하는 상수
    BASIC,
    VIP
}
