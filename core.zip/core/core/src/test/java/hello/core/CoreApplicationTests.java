package hello.core;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreApplicationTests { // 스트링 부트 테스트는 자동으로 생성되는 것, 그래서 오래걸림. 단일 테스트가 중요하다.


	@Test
	void contextLoads() {
	}

}
